package com.javatpoint.service;

import com.javatpoint.models.DeploymentRequest;
import com.javatpoint.models.IngressRequest;
import com.javatpoint.models.ServiceRequest;
import io.kubernetes.client.custom.IntOrString;
import io.kubernetes.client.openapi.ApiClient;
import io.kubernetes.client.openapi.ApiException;
import io.kubernetes.client.openapi.Configuration;
import io.kubernetes.client.openapi.apis.AppsV1Api;
import io.kubernetes.client.openapi.apis.CoreV1Api;
import io.kubernetes.client.openapi.apis.NetworkingV1Api;
import io.kubernetes.client.openapi.models.*;
import io.kubernetes.client.util.Config;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@Service
public class KubernetesService {

    public String createDeploymentResource(DeploymentRequest request) throws ApiException, IOException {

        try {

            // Create the Kubernetes client
            ApiClient client = Config.defaultClient();
            Configuration.setDefaultApiClient(client);

            // Create a AppsV1Api instance
            AppsV1Api appsV1Api = new AppsV1Api();

            // Create an instance of V1Deployment
            V1Deployment deployment = new V1Deployment();

            deployment.setApiVersion("apps/v1");
            deployment.setKind("Deployment");
            // Set the metadata for the Deployment
            V1ObjectMeta metadata = new V1ObjectMeta();
            metadata.setName(request.getDeploymentName());
            //set labels
            Map<String, String> labels = new HashMap<>();
            labels.put(request.getAppKey(), request.getAppValue());
            metadata.setLabels(labels);
            //set metadata
            deployment.setMetadata(metadata);

            // Set the spec for the Deployment
            V1DeploymentSpec spec = new V1DeploymentSpec();
            spec.setReplicas(request.getReplicas());
            //set selector
            V1LabelSelector v1LabelSelector = new V1LabelSelector();
            v1LabelSelector.setMatchLabels(labels);
            spec.setSelector(v1LabelSelector);

            // Set the pod template spec
            V1PodTemplateSpec template = new V1PodTemplateSpec();

            V1ObjectMeta v1ObjectMeta = new V1ObjectMeta();
            v1ObjectMeta.setLabels(labels);
            //set template metaData
            template.setMetadata(v1ObjectMeta);

            // Set the pod spec
            V1PodSpec podSpec = new V1PodSpec();

            // Set the container spec
            V1Container container = new V1Container();
            container.setImage(request.getContainerImage());
            container.setName(request.getContainerName());
            V1ContainerPort v1ContainerPort = new V1ContainerPort();
            v1ContainerPort.setContainerPort(request.getContainerPort());
            container.setPorts(Collections.singletonList(v1ContainerPort));
            // Add the container to the pod spec
            podSpec.setContainers(Collections.singletonList(container));

            // Set the pod spec in the pod template spec
            template.setSpec(podSpec);

            // Set the pod template spec in the Deployment spec
            spec.setTemplate(template);

            // Set the Deployment spec in the Deployment object
            deployment.setSpec(spec);

            // Create the Deployment resource using the Kubernetes Java client library
            appsV1Api.createNamespacedDeployment(request.getNamespace(), deployment, null, null, null, null);

            return "deployment created successfully";
        } catch (ApiException e) {
            return "Error creating deployment: " + e.getMessage();
        }
    }


    public String createServiceResource(ServiceRequest serviceRequest) throws ApiException, IOException {

        try {
            // Create the Kubernetes client
            ApiClient client = Config.defaultClient();
            Configuration.setDefaultApiClient(client);

            // Create a CoreV1Api instance
            CoreV1Api coreApi = new CoreV1Api();

            // Create a Service resource
            V1Service service = new V1Service();
            service.setApiVersion("v1");
            service.setKind("Service");

            V1ObjectMeta serviceMetadata = new V1ObjectMeta();
            //set service name
            serviceMetadata.setName(serviceRequest.getName());
            service.setMetadata(serviceMetadata);

            V1ServiceSpec serviceSpec = new V1ServiceSpec();
            //set service name
            serviceSpec.setType(serviceRequest.getType());

            //add service selector
            Map<String, String> selector = new HashMap<>();
            selector.put(serviceRequest.getAppKey(), serviceRequest.getAppValue());
            serviceSpec.setSelector(selector);

            //add service ports
            V1ServicePort servicePort = new V1ServicePort();
            servicePort.setPort(serviceRequest.getPort());
            servicePort.setName("http");
            servicePort.setProtocol("TCP");
            servicePort.setTargetPort(new IntOrString(serviceRequest.getTargetPort()));
            serviceSpec.setPorts(Collections.singletonList(servicePort));

            service.setSpec(serviceSpec);

            // Create the Service in Kubernetes
            coreApi.createNamespacedService(serviceRequest.getNamespace(), service, null, null, null, null);

            return "Service created successfully";
        } catch (ApiException e) {
            return "Error creating service: " + e.getMessage();
        }
    }

    public String createIngressResource(IngressRequest ingressRequest) throws ApiException, IOException {
        try {
            // Create the Kubernetes client
            ApiClient client = Config.defaultClient();
            Configuration.setDefaultApiClient(client);

            // Create a NetworkingV1beta1Api instance
            NetworkingV1Api networkingApi = new NetworkingV1Api();

            // Create an Ingress resource
            V1Ingress ingress = new V1Ingress();
            ingress.setApiVersion("networking.k8s.io/v1");
            ingress.setKind("Ingress");

            V1ObjectMeta ingressMetadata = new V1ObjectMeta();
            ingressMetadata.setName(ingressRequest.getName());
            ingress.setMetadata(ingressMetadata);

            V1IngressSpec ingressSpec = new V1IngressSpec();

            //add rules
            V1IngressRule ingressRule = new V1IngressRule();
            ingressRule.setHost(ingressRequest.getHost());

            // add path
            V1HTTPIngressPath httpIngressPath = new V1HTTPIngressPath();
            httpIngressPath.setPath(ingressRequest.getPath());
            httpIngressPath.setPathType("Prefix");

            //add backend
            V1IngressBackend v1IngressBackend = new V1IngressBackend();

            V1IngressServiceBackend v1IngressServiceBackend = new V1IngressServiceBackend();
            v1IngressServiceBackend.setName(ingressRequest.getServiceName());

            V1ServiceBackendPort v1ServiceBackendPort = new V1ServiceBackendPort();
            v1ServiceBackendPort.setNumber(ingressRequest.getServicePort());
            v1IngressServiceBackend.setPort(v1ServiceBackendPort);


            //set service in the backend
            v1IngressBackend.setService(v1IngressServiceBackend);

            //set backend in the path
            httpIngressPath.setBackend(v1IngressBackend);

            //set paths
            V1HTTPIngressRuleValue httpIngressRuleValue = new V1HTTPIngressRuleValue();
            httpIngressRuleValue.setPaths(Collections.singletonList(httpIngressPath));

            //set http
            ingressRule.setHttp(httpIngressRuleValue);


            //set rule
            ingressSpec.setRules(Collections.singletonList(ingressRule));

            //set specs
            ingress.setSpec(ingressSpec);

            // Create the Ingress in Kubernetes
            networkingApi.createNamespacedIngress(ingressRequest.getNamespace(), ingress, null, null, null, null);
            return "Ingress created successfully";
        } catch (ApiException e) {
            return "Error creating Ingress: " + e.getMessage();
        }
    }


}
