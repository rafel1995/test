package com.javatpoint.controller;
import com.javatpoint.service.KubernetesService;
import com.javatpoint.models.DeploymentRequest;
import com.javatpoint.models.IngressRequest;
import com.javatpoint.models.ServiceRequest;
import io.kubernetes.client.openapi.ApiException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;


@RestController
@RequestMapping("/kubernetes")
public class KubernetesController {

    @Autowired
    private  KubernetesService kubernetesService;
    @PostMapping("/createDeployment")
    public ResponseEntity<String> createDeployment(@RequestBody DeploymentRequest request) {
        try {
            // Use the Kubernetes Java client library to create the Deployment resource
            kubernetesService.createDeploymentResource(request);

            return ResponseEntity.ok("Deployment created successfully.");
        } catch (ApiException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error creating Deployment: " + e.getMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @PostMapping("/create-service")
    public ResponseEntity<String> createService(@RequestBody ServiceRequest serviceRequest) {

        try {
            // Use the Kubernetes Java client library to create the Service resource
            kubernetesService.createServiceResource(serviceRequest);

            return ResponseEntity.ok("Service created successfully.");
        } catch (ApiException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error creating Service: " + e.getMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    @PostMapping("/create-ingress")
    public ResponseEntity<String> createIngress(@RequestBody IngressRequest ingressRequest) {

        try {
            // Use the Kubernetes Java client library to create the Ingress resource
            kubernetesService.createIngressResource(ingressRequest);

            return ResponseEntity.ok("Ingress created successfully.");
        } catch (ApiException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error creating Ingress: " + e.getMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
