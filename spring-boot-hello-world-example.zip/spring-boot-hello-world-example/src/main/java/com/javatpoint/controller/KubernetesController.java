package com.javatpoint.controller;

import com.javatpoint.models.IngressRequest;
import com.javatpoint.models.ServiceRequest;
import io.kubernetes.client.custom.IntOrString;
import io.kubernetes.client.openapi.ApiClient;
import io.kubernetes.client.openapi.ApiException;
import io.kubernetes.client.openapi.Configuration;
import io.kubernetes.client.openapi.apis.CoreV1Api;
import io.kubernetes.client.openapi.models.*;
import io.kubernetes.client.openapi.apis.NetworkingV1Api;
import io.kubernetes.client.util.Config;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@RestController
public class KubernetesController {

    @PostMapping("/create-service")
    public String createService(@RequestBody ServiceRequest serviceRequest) {
        try {
            // Create the Kubernetes client
            ApiClient client = Config.defaultClient();
            Configuration.setDefaultApiClient(client);

            // Create a CoreV1Api instance
            CoreV1Api coreApi = new CoreV1Api();

            // Create a Service resource
            V1Service service = new V1Service();
            service.setApiVersion("v1");
            service.setKind("Service");

            V1ObjectMeta serviceMetadata = new V1ObjectMeta();
            serviceMetadata.setName(serviceRequest.getName());
            service.setMetadata(serviceMetadata);

            V1ServiceSpec serviceSpec = new V1ServiceSpec();
            serviceSpec.setType(serviceRequest.getType());

            Map<String,String> selector = new HashMap<>();
            selector.put(serviceRequest.getAppKey(),serviceRequest.getAppValue());
            serviceSpec.setSelector(selector);


            V1ServicePort servicePort = new V1ServicePort();
            servicePort.setPort(serviceRequest.getPort());
            servicePort.setName("http");
            servicePort.setProtocol("TCP");
            servicePort.setTargetPort(new IntOrString(serviceRequest.getTargetPort()));
            serviceSpec.setPorts(Collections.singletonList(servicePort));

            service.setSpec(serviceSpec);

            // Create the Service in Kubernetes
            coreApi.createNamespacedService(serviceRequest.getNamespace(), service, null, null, null, null);

            return "Service created successfully";
        } catch (ApiException e) {
            return "Error creating service: " + e.getMessage();
        } catch (IOException e) {
            return "Error reading Kubernetes configuration: " + e.getMessage();
        }
    }

    @PostMapping("/create-ingress")
    public String createIngress(@RequestBody IngressRequest ingressRequest) {
        try {
            // Create the Kubernetes client
            ApiClient client = Config.defaultClient();
            Configuration.setDefaultApiClient(client);

            // Create a NetworkingV1beta1Api instance
            NetworkingV1Api networkingApi = new NetworkingV1Api();

            // Create an Ingress resource
            V1Ingress ingress = new V1Ingress();
            ingress.setApiVersion("networking.k8s.io/v1beta1");
            ingress.setKind("Ingress");

            V1ObjectMeta ingressMetadata = new V1ObjectMeta();
            ingressMetadata.setName(ingressRequest.getName());
            ingress.setMetadata(ingressMetadata);

            V1IngressSpec ingressSpec = new V1IngressSpec();
           V1IngressRule ingressRule = new V1IngressRule();

           V1HTTPIngressPath httpIngressPath = new V1HTTPIngressPath();
            httpIngressPath.setPath(ingressRequest.getPath());

            V1IngressBackend v1IngressBackend = new V1IngressBackend();

            V1IngressServiceBackend v1IngressServiceBackend = new V1IngressServiceBackend();
            v1IngressServiceBackend.setName(ingressRequest.getServiceName());

            V1ServiceBackendPort v1ServiceBackendPort = new V1ServiceBackendPort();
            v1ServiceBackendPort.setNumber(80);

            v1IngressServiceBackend.setPort(v1ServiceBackendPort);

            v1IngressBackend.setService(v1IngressServiceBackend);
            httpIngressPath.setBackend(v1IngressBackend);

           V1HTTPIngressRuleValue httpIngressRuleValue = new V1HTTPIngressRuleValue();
            httpIngressRuleValue.setPaths(Collections.singletonList(httpIngressPath));

            ingressRule.setHttp(httpIngressRuleValue);
            ingressSpec.setRules(Collections.singletonList(ingressRule));
            ingress.setSpec(ingressSpec);

            // Create the Ingress in Kubernetes
            networkingApi.createNamespacedIngress(ingressRequest.getNamespace(), ingress, null, null, null, null);

            return "Ingress created successfully";
        } catch (ApiException e) {
            return "Error creating Ingress: " + e.getMessage();
        } catch (IOException e) {
            return "Error reading Kubernetes configuration: " + e.getMessage();
        }
    }




}
