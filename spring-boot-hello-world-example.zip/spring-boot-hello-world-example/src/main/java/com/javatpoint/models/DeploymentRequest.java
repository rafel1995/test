package com.javatpoint.models;

public class DeploymentRequest {

    String deploymentName;
    Integer replicas;
    String containerImage;
    String containerName;
    Integer containerPort;
    String namespace;

    private String appKey;
    private String appValue;

    public DeploymentRequest() {

    }


    public DeploymentRequest(String deploymentName, Integer replicas, String containerImage, String containerName, Integer containerPort, String namespace, String appKey, String appValue) {
        this.deploymentName = deploymentName;
        this.replicas = replicas;
        this.containerImage = containerImage;
        this.containerName = containerName;
        this.containerPort = containerPort;
        this.namespace = namespace;
        this.appKey = appKey;
        this.appValue = appValue;
    }

    public Integer getContainerPort() {
        return containerPort;
    }

    public void setContainerPort(Integer containerPort) {
        this.containerPort = containerPort;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getAppValue() {
        return appValue;
    }

    public void setAppValue(String appValue) {
        this.appValue = appValue;
    }

    public String getDeploymentName() {
        return deploymentName;
    }

    public void setDeploymentName(String deploymentName) {
        this.deploymentName = deploymentName;
    }

    public Integer getReplicas() {
        return replicas;
    }

    public void setReplicas(Integer replicas) {
        this.replicas = replicas;
    }

    public String getContainerImage() {
        return containerImage;
    }

    public void setContainerImage(String containerImage) {
        this.containerImage = containerImage;
    }

    public String getContainerName() {
        return containerName;
    }

    public void setContainerName(String containerName) {
        this.containerName = containerName;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }
}
